print("Welcome to the NameYourBand!")
city = input("Which city did you grow up in?\n")
pet = input("What is your pet's name?\n")
band_name = city+" "+pet
print("Your band name could be "+band_name)